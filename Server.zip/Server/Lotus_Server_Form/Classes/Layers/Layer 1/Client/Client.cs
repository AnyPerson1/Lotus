﻿using Server.Stage1.DataRecieve;
using Server.Stage1.Libraries;
using Server.StaticVariables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Server.Stage2.Orientation;
using System.Diagnostics;
using Server.Logger;

namespace Lotus_Server_Form.Stage_1.Client
{
    internal partial class Client : DataRecieve
    {
        // Constructor
        private TcpClient client;
        public Client(TcpClient client) // DataRecieve sınıfının constructor'ını çağır
        {
            if (StaticVariables.status)
            {
                this.client = client;
                _ = StartListeningAsync(); // Asenkron dinlemeyi başlat
            }
        }
        public Client() // DataRecieve sınıfının constructor'ını çağır
        {
        }

        // Asenkron dinleme metodu
        private async Task StartListeningAsync()
        {
            SetStatus(true);
            Distribution distribution = new Distribution();
            while (true)
            {
                try
                {
                    var data = await StartListeningClientAsync(client);
                    if (data != null)
                    {
                        distribution.DefineMessage(data,client,false);
                    }
                }
                catch (Exception ex)
                {
                    Logger.Log($"Asenkron veri dinleme esnasında sorun : {ex.ToString()}",Logger.LogLayer.Layer1);
                    break; // Hata durumunda döngüden çık
                }
            }
        }

        public static async Task<TcpClient> AcceptClientAsync()
        {
            if (StaticVariables.status)
            {
                while (true)
                {
                    TcpClient clientToAccept = await StaticVariables.Listener.AcceptTcpClientAsync();
                    if (clientToAccept != null)
                    {
                        return clientToAccept;
                    }
                }
            }
            else return null;
        }
    }

}
