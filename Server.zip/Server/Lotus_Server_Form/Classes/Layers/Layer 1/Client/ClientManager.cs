﻿using Server.Logger;
using Server.StaticVariables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Lotus_Server_Form.Stage_1.Client
{
    internal partial class ClientManager
    {
        public async Task GetClientAsync() // işlemler başlarken kullanılacak method
        {
            if (StaticVariables.status)
            {
                TcpClient client = await Client.AcceptClientAsync();

                if (client != null)
                {
                    StaticVariables.Clients.Add(client);
                    Client startClient = new Client(client);
                    Logger.Log($"{client.Client.RemoteEndPoint} bağlandı.", Logger.LogLayer.Layer1);
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Client onaylama sırasında sıradışı bir hata meydana geldi.");
                }
            }
        }
    }

}
